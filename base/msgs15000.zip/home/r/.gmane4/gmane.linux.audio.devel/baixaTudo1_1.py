import os

for i in xrange(0,20001):
    os.system("wget http://download.gmane.org/gmane.linux.audio.devel/%i/%i -O %i" % (i,i+1,i))
